import random
UNK = 'UNK'
# This file contains the dataset in a useful way. We populate a list of
# Trees to train/test our Neural Nets such that each Tree contains any
# number of Node objects.

# The best way to get a feel for how these objects are used in the program is to drop pdb.set_trace() in a few places throughout the codebase
# to see how the trees are used.. look where loadtrees() is called etc..


class Node:  # a node in the tree
    def __init__(self, label, word=None):
        self.label = label
        self.word = word
        self.parent = None  # reference to parent(with 8 children)
        self.left = None  # reference to leftest child
        self.left2 = None   # ...
        # reference to rightest child
        # true if I am a leaf (could have probably derived this from if I have
        # a word)
        self.isLeaf = False
        # true if we have finished performing fowardprop on this node (note,
        # there are many ways to implement the recursion.. some might not
        # require this flag)
class BinNode:
    def __init__(self, label, word=None):
        self.label = label
        self.word = word
        self.parent = None  # reference to parent(with 8 children)
        self.left = None  # reference to leftest child
        self.right = None  # reference to rightest child
        # true if I am a leaf (could have probably derived this from if I have
        # a word)
        self.isLeaf = False

class Tree:
    def __init__(self, treeString, openChar='(', closeChar=')'):
        tokens = []
        self.open = '('
        self.close = ')'
        for toks in treeString.strip().split():
            if toks !="":
                tokens += list(toks)
        self.root = self.parse(tokens)
        # get list of labels as obtained through a post-order traversal
        self.labels = get_labels(self.root)
        self.num_words = len(self.labels)
    def newNode(self,lable,parent=None,left=None,right=None):
        node = Node(lable)
        node.parent = parent
        node.left = left
        node.right = right
        return node

    def parse(self, tokens, parent=None):
        NULLL = []
        if tokens == NULLL:
            return

        assert tokens[0] == self.open, "Malformed tree"
        assert tokens[-1] == self.close, "Malformed tree"

        split = 1
        # position after open and label
        while str.isdigit(tokens[split])==True:
            split += 1
        split_flag = split
        countOpen = countClose = 0

        if tokens[split] == self.open:
            countOpen += 1
            split += 1
        # Find where left child and right child split
        while countOpen != countClose:
            if tokens[split] == self.open:
                countOpen += 1
            if tokens[split] == self.close:
                countClose += 1
            split += 1


        # New node
        node = Node(int("".join(tokens[1:3])))  # zero index labels

        node.parent = parent

        # leaf Node
        if countOpen == 0:
            split1 = 1
            while str.isdigit(tokens[split1])==True:
                split1 += 1
            node.word = ''.join(tokens[split1:-1]).lower()  # lower case?
            node.isLeaf = True
            return node

        node.left = self.parse(tokens[split_flag:split], parent=node)

        if split != (len(tokens) - 1):

            subnode_open_flag=[]
            subnode_close_flag=[]
            count_all2 = 0
            count_open_sign2 = 0
            count_close_sign2 = 0
            #subnode_open_flag.append(3)
            #subnode_close_flag.append(split-1)
            subnode_open_flag.append(split)
            for lll in tokens[split:len(tokens)-2]:
                if lll == "(":
                    count_open_sign2 += 1
                if lll == ")":
                    count_close_sign2 += 1
                if count_open_sign2 == count_close_sign2 :
                    subnode_close_flag.append(count_all2+split)
                    if subnode_close_flag[-1] != (len(tokens)-2):
                        subnode_open_flag.append(count_all2+split+1)
                count_all2 += 1
            subnode_close_flag.append(len(tokens)-2)
            subnode_number = len(subnode_open_flag)
            if subnode_number == 1:
                node.left2 = self.parse(tokens[subnode_open_flag[0]:subnode_close_flag[0]+1], parent=node)
            if subnode_number == 2:
                node.left2 = self.newNode(9,parent=node,left=None,right=None)
                node.left2.left = self.parse(tokens[subnode_open_flag[0]:subnode_close_flag[0]+1], parent=node.left2)
                node.left2.right = self.parse(tokens[subnode_open_flag[1]:subnode_close_flag[1]+1], parent=node.left2)
            if subnode_number == 3:
                node.left2 = self.newNode(9,parent=node,left=None,right=None)
                node.left2.left = self.parse(tokens[subnode_open_flag[0]:subnode_close_flag[0]+1], parent=node.left2)
                node.left2.right = self.newNode(9,parent=node.left2,left=None,right=None)
                node.left2.right.left = self.parse(tokens[subnode_open_flag[1]:subnode_close_flag[1]+1], parent=node.left2.right)
                node.left2.right.right = self.parse(tokens[subnode_open_flag[2]:subnode_close_flag[2]+1], parent=node.left2.right)
            if subnode_number == 4:
                node.left2 = self.newNode(9,parent=node,left=None,right=None)
                node.left2.left = self.parse(tokens[subnode_open_flag[0]:subnode_close_flag[0]+1], parent=node.left2)
                node.left2.right = self.newNode(9,parent=node.left2,left=None,right=None)
                node.left2.right.left = self.parse(tokens[subnode_open_flag[1]:subnode_close_flag[1]+1], parent=node.left2.right)
                node.left2.right.right = self.newNode(9,parent=node.left2.right,left=None,right=None)
                node.left2.right.right.left = self.parse(tokens[subnode_open_flag[2]:subnode_close_flag[2]+1], parent=node.left2.right.right)
                node.left2.right.right.right = self.parse(tokens[subnode_open_flag[3]:subnode_close_flag[3]+1], parent=node.left2.right.right)
            if subnode_number == 5:
                node.left2 = self.newNode(9,parent=node,left=None,right=None)
                node.left2.left = self.parse(tokens[subnode_open_flag[0]:subnode_close_flag[0]+1], parent=node.left2)
                node.left2.right = self.newNode(9,parent=node.left2,left=None,right=None)
                node.left2.right.left = self.parse(tokens[subnode_open_flag[1]:subnode_close_flag[1]+1], parent=node.left2.right)
                node.left2.right.right = self.newNode(9,parent=node.left2.right,left=None,right=None)
                node.left2.right.right.left = self.parse(tokens[subnode_open_flag[2]:subnode_close_flag[2]+1], parent=node.left2.right.right)
                node.left2.right.right.right = self.newNode(9,parent=node.left2.right.right,left=None,right=None)
                node.left2.right.right.right.left = self.parse(tokens[subnode_open_flag[3]:subnode_close_flag[3]+1], parent=node.left2.right.right.right)
                node.left2.right.right.right.right = self.parse(tokens[subnode_open_flag[4]:subnode_close_flag[4]+1], parent=node.left2.right.right.right)

            if subnode_number == 6:
                node.left2 = self.newNode(9,parent=node,left=None,right=None)
                node.left2.left = self.parse(tokens[subnode_open_flag[0]:subnode_close_flag[0]+1], parent=node.left2)
                node.left2.right = self.newNode(9,parent=node.left2,left=None,right=None)
                node.left2.right.left = self.parse(tokens[subnode_open_flag[1]:subnode_close_flag[1]+1], parent=node.left2.right)
                node.left2.right.right = self.newNode(9,parent=node.left2.right,left=None,right=None)
                node.left2.right.right.left = self.parse(tokens[subnode_open_flag[2]:subnode_close_flag[2]+1], parent=node.left2.right.right)
                node.left2.right.right.right = self.newNode(9,parent=node.left2.right.right,left=None,right=None)
                node.left2.right.right.right.left = self.parse(tokens[subnode_open_flag[3]:subnode_close_flag[3]+1], parent=node.left2.right.right.right)
                node.left2.right.right.right.right = self.newNode(9,parent=node.left2.right.right.right,left=None,right=None)
                node.left2.right.right.right.right.left = self.parse(tokens[subnode_open_flag[4]:subnode_close_flag[4]+1], parent=node.left2.right.right.right.right)
                node.left2.right.right.right.right.right = self.parse(tokens[subnode_open_flag[5]:subnode_close_flag[5]+1], parent=node.left2.right.right.right.right)

            if subnode_number == 7:
                node.left2 = self.newNode(9,parent=node,left=None,right=None)
                node.left2.left = self.parse(tokens[subnode_open_flag[0]:subnode_close_flag[0]+1], parent=node.left2)
                node.left2.right = self.newNode(9,parent=node.left2,left=None,right=None)
                node.left2.right.left = self.parse(tokens[subnode_open_flag[1]:subnode_close_flag[1]+1], parent=node.left2.right)
                node.left2.right.right = self.newNode(9,parent=node.left2.right,left=None,right=None)
                node.left2.right.right.left = self.parse(tokens[subnode_open_flag[2]:subnode_close_flag[2]+1], parent=node.left2.right.right)
                node.left2.right.right.right = self.newNode(9,parent=node.left2.right.right,left=None,right=None)
                node.left2.right.right.right.left = self.parse(tokens[subnode_open_flag[3]:subnode_close_flag[3]+1], parent=node.left2.right.right.right)
                node.left2.right.right.right.right = self.newNode(9,parent=node.left2.right.right.right,left=None,right=None)
                node.left2.right.right.right.right.left = self.parse(tokens[subnode_open_flag[4]:subnode_close_flag[4]+1], parent=node.left2.right.right.right.right)
                node.left2.right.right.right.right.right = self.newNode(9,parent=node.left2.right.right.right.right,left=None,right=None)
                node.left2.right.right.right.right.right.left = self.parse(tokens[subnode_open_flag[5]:subnode_close_flag[5]+1], parent=node.left2.right.right.right.right.right)
                node.left2.right.right.right.right.right.right = self.parse(tokens[subnode_open_flag[6]:subnode_close_flag[6]+1], parent=node.left2.right.right.right.right.right)


        return node

    def get_words(self):
        leaves = getLeaves(self.root)
        words = [node.word for node in leaves]
        return words


def leftTraverse(node, nodeFn=None, args=None):
    """
    Recursive function traverses tree
    from left to right. 
    Calls nodeFn at each node
    """
    if node is None:
        return
    leftTraverse(node.left, nodeFn, args)
    leftTraverse(node.left2, nodeFn, args)
    nodeFn(node, args)


def getLeaves(node):
    if node is None:
        return []
    if node.isLeaf:
        return [node]
    else:
        return getLeaves(node.left) +getLeaves(node.left2)

def get_labels(node):
    if node is None:
        return []
    return get_labels(node.left) + get_labels(node.left2)

def clearFprop(node, words):
    node.fprop = False


def stripTestTreesLabel(dataSet,Label_File):
    file1 = 'input/%s.tree' % dataSet
    START = 16
    with open(file1, 'r') as fid1:
        raw_text = fid1.read()
    AA = raw_text.replace("\n","").replace(" ","").replace("(..))","(12.))").replace("(,,)","(13,)").\
        replace("(::)","(14:)").replace("(\"\")","(15,\")").replace("(:*)","(90:*)").replace("(:-)","(90:-)")
    file2 = 'trees/%s.txt' % Label_File
    with open(file2, 'r') as fid2:
        Labels = [l.replace(" \n","") for l in fid2.readlines()]
    Labels.sort(key=lambda x: len(x), reverse=True)
    for label in Labels:
        AA = AA.replace(label,str(START))
        START += 1

    return AA.replace("(-L88--L88-)","(88-L)").replace("(-R88--R88-)","(88-R)").\
        replace("(:;)","(92:;)").replace("(:/)","(98:/)").replace("(```)","(96```)").\
        replace("(''')","(94''')").replace("(:i)","(93i)").replace("($d)","(95$d)").\
        replace('(``','(90``').replace('($$','(90$$').replace('(##','(90##').\
        replace('(..','(90..').replace('(,;','(90,;').replace('($=','(90$=').\
        replace("(''","(90''").replace('(.?','(90.?').replace('(.!','(90.!').\
        replace( '(:e', '(90:e').replace('(,-','(90,-').replace('($b','(90$b').\
        replace('(,a','(90,a').replace('(:p','(90:p')

def pre_test_data(BB,CC):
    count_all = 0
    count_open_sign = 0
    count_close_sign = 0
    length_increase = 1

    SentLable_neg="0"
    SentLable_pos="1"
    CC[1] = SentLable_neg
    CC[2] = SentLable_neg
    for ll in BB:
        if ll == "(":
            count_open_sign += 1
        if ll == ")":
            count_close_sign += 1
        if count_open_sign == count_close_sign :
            CC.insert(count_all+length_increase,"\n")
            if (count_all+length_increase) < (len(CC)+1600)/2:
                CC[count_all+length_increase+2] = SentLable_neg
                CC[count_all+length_increase+3] = SentLable_neg
            elif (len(CC)+1600)/2 <= (count_all+length_increase) < (len(CC)-2):
                CC[count_all+length_increase+2] = SentLable_pos
                CC[count_all+length_increase+3] = SentLable_pos
            length_increase += 1
        count_all += 1

def loadTestTrees(dataSet='test'):
    """
    Loads training trees. Maps leaf node words to word ids.
    """

    BB=[]
    CC=[]
    BB=list(stripTestTreesLabel(dataSet,'Bracket_Labels'))
    CC=list(stripTestTreesLabel(dataSet,'Bracket_Labels'))

    pre_test_data(BB,CC)
    file_object = open('trees/test_data.txt', 'w')
    file_object.write("".join(CC))
    file_object.close()

    file = 'trees/test_data.txt'
    print "Loading testing_data.txt.tree trees.."
    with open(file, 'r') as fid:
        #trees = [Tree(l) for l in fid.readlines() if "(" in l ]
        trees = []
        for l in fid.readlines():
            if "(" in l and Tree(l).root.left != None:
               trees.append(Tree(l))

    return trees

def loadTrees(dataSet='train'):
    """
    Loads training trees. Maps leaf node words to word ids.
    """
    file = 'trees/%s.txt' % dataSet
    with open(file, 'r') as fid:
        trees = []
        for l in fid.readlines():
            if "(" in l and Tree(l).root.left != None:
               trees.append(Tree(l))

    return trees

def simplified_data(num_train, num_dev, num_test):
    rndstate = random.getstate()
    random.seed(0)
    trees = loadTrees('train_data') + loadTrees('val_data') + loadTestTrees('testing_data.txt')

    make_BinTree(trees)
    print(len(trees))
    for t in trees:
        if t.root.label == 11:
            t.root.label = 1
    pos_trees = [t for t in trees if t.root.label==1]
    neg_trees = [t for t in trees if t.root.label==0]

    #split into train, dev, test
    print len(pos_trees), len(neg_trees)
    pos_trees = sorted(pos_trees, key=lambda t: len(t.get_words()))
    neg_trees = sorted(neg_trees, key=lambda t: len(t.get_words()))
    num_train/=2
    num_dev/=2
    num_test/=2
    train = pos_trees[:num_train] + neg_trees[:num_train]
    dev = pos_trees[num_train : num_train+num_dev] + neg_trees[num_train : num_train+num_dev]
    test = pos_trees[num_train+num_dev : num_train+num_dev+num_test] + neg_trees[num_train+num_dev : num_train+num_dev+num_test]
    random.shuffle(train)
    random.shuffle(dev)
    #random.shuffle(test)
    random.setstate(rndstate)


    return train, dev, test


def binarize_labels(trees):
    def binarize_node(node, _):
        if node.label<2:
            node.label = node.label
        elif node.label>2:
            node.label = node.label
    for tree in trees:
        leftTraverse(tree.root, binarize_node, None)
        tree.labels = get_labels(tree.root)

def make_BinTree(trees):
    def strip_single_child_node(node, _):
        if node.left != None and node.left2 == None:
            if node.parent.left == node:
                node.left.parent = node.parent
                node.parent.left = node.left
            else :
                node.left.parent = node.parent
                node.parent.left2 = node.left

            node = None

    for tree in trees:

        leftTraverse(tree.root,strip_single_child_node , None)

