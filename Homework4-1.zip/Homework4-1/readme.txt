

giga-fren.release2.fixed.en
giga-fren.release2.fixed.fr

newstest2013.en
newstest2013.fr
