# Recursive-neural-networks-TensorFlow
This repository contains the implementation of a signle hidden layer Recursive Neural Network. Implemented in python using TensorFlow. Used the trained models for the task of Positive/Negative sentiment analysis. This code is the solution for the third programming assignment from "CS224d: Deep learning for Natural Language Processing", Stanford University.
